package com.example.juba.chatmessenger.ui.login;

import android.util.Log;

import com.example.juba.chatmessenger.repository.AuthRepo;
import com.example.juba.chatmessenger.utils.StateResource;


import javax.inject.Inject;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MediatorLiveData;
import androidx.lifecycle.ViewModel;
import io.reactivex.CompletableObserver;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class LoginViewModel extends ViewModel {

    private static final String TAG = "LoginViewModel";
    AuthRepo authRepo;
    CompositeDisposable disposable = new CompositeDisposable();
    MediatorLiveData<StateResource> onLogin = new MediatorLiveData<>();


    @Inject
    public LoginViewModel(AuthRepo authRepo) {
        Log.e(TAG,"loginViewModel exist");
        this.authRepo = authRepo;
    }



    //void not completable
    public void loginUser(String email, String password) {
        authRepo.loginUser(email, password)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new CompletableObserver() {
                    @Override
                    public void onSubscribe(Disposable d) {
                        onLogin.setValue(StateResource.loading());

                    }

                    @Override
                    public void onComplete() {
                        Log.e(TAG, "onComplete successfull loging");

                        onLogin.setValue(StateResource.success());

                    }

                    @Override
                    public void onError(Throwable e) {
                        Log.e(TAG, "onError: proplem here"+e.getMessage());
                        onLogin.setValue(StateResource.error(e.getMessage()));


                    }
                });


    }


    public void logOut() {
        authRepo.logOut();

    }

    public LiveData<StateResource> getOnLogin() {
        return onLogin;
    }


}

