package com.example.juba.chatmessenger.utils;

public class Constants {

    public static final String User_node = "users";
    public static final String profile_image_node = "image";
    public static final String TEXT_TYPE = "text";
    public static final String MESSAGE_NODE = "messages";



}
