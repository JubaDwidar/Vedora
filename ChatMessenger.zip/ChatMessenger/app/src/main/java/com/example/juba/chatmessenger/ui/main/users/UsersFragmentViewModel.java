package com.example.juba.chatmessenger.ui.main.users;

import javax.inject.Inject;

import androidx.lifecycle.ViewModel;

public class UsersFragmentViewModel extends ViewModel {

    @Inject
    public UsersFragmentViewModel()
    {
    }
}
