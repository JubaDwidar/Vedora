package com.example.juba.chatmessenger.notification;

public class MyToken {
    private String token;

    public MyToken(String token) {
        this.token = token;
    }

    public MyToken() {
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
