package com.example.juba.chatmessenger.ui.register;

import android.util.Log;

import com.example.juba.chatmessenger.repository.AuthRepo;
import com.example.juba.chatmessenger.utils.StateResource;

import javax.inject.Inject;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MediatorLiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import io.reactivex.CompletableObserver;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class RegisterViewModel extends ViewModel {

    private static final String TAG = "RegisterViewModel";

    AuthRepo authRepo;
    CompositeDisposable disposable = new CompositeDisposable();
    MutableLiveData<StateResource> onRegister = new MutableLiveData<>();

    @Inject
    public RegisterViewModel(AuthRepo authRepo) {
        this.authRepo = authRepo;
    }

    public void createUser(String email, String password) {
        authRepo.createUser(email, password)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new CompletableObserver() {
                    @Override
                    public void onSubscribe(Disposable d) {
                        onRegister.setValue(StateResource.loading());
                    }

                    @Override
                    public void onComplete() {
                        onRegister.setValue(StateResource.success());
                        Log.e(TAG,"afterRegister");


                    }

                    @Override
                    public void onError(Throwable e) {
                        onRegister.setValue(StateResource.error(e.getMessage()));
                    }
                });


    }
    public LiveData<StateResource> getOnRegister()
    {
        return onRegister;

    }

    @Override
    protected void onCleared() {
        super.onCleared();
        disposable.clear();
    }
}

