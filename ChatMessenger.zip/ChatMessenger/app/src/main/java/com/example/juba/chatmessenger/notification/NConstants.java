package com.example.juba.chatmessenger.notification;

public class NConstants {

    public static String BASE_URL="https://fcm.googleapis.com/";
    public static String SERVER_Key="AAAABU3jGHs:APA91bFQMm2NU4mIhhDdpKlNICR-1YqoVuHLfCVLWhZtvogB7AdGSq2HGqUozzWnkBwYE_yGjkOhN-6-Ax9IPDQZBEoxfy3V08vf52NS9tIJ2ZkuAh-WvEKdxxJ-dZoJuDxcr0jBVEoC";
    public static String CONTENT_TYPE="application/json";


}
