package com.example.juba.chatmessenger.ui.settings;

import android.graphics.Bitmap;
import android.util.Log;

import com.example.juba.chatmessenger.datasource.model.Users;
import com.example.juba.chatmessenger.repository.AuthRepo;
import com.example.juba.chatmessenger.repository.DataRepo;
import com.example.juba.chatmessenger.utils.StateResource;
import com.google.firebase.firestore.DocumentSnapshot;

import org.reactivestreams.Subscription;

import javax.inject.Inject;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MediatorLiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import io.reactivex.CompletableObserver;
import io.reactivex.FlowableSubscriber;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class SettingsViewModel extends ViewModel {


    private static final String TAG = "SettingsViewModel";

    private String uId;
    private AuthRepo authRepo;
    private DataRepo dataRepo;
    private CompositeDisposable disposable = new CompositeDisposable();


    private MediatorLiveData<Users> onUser = new MediatorLiveData<>();
    private MutableLiveData<StateResource> onStatusChange = new MutableLiveData<>();
    private MutableLiveData<StateResource> onDisplayImageChange = new MutableLiveData<>();

    @Inject
    public SettingsViewModel(AuthRepo authRepo, DataRepo dataRepo) {
        this.dataRepo = dataRepo;
        this.authRepo = authRepo;
        uId=this.authRepo.getCurrentUId();
        getUserInfo(uId);
    }


    public void getUserInfo(String uId) {
// الميثود دي عاوزينها تتنفذ اول ما الاكتفتي تشتغل فعشان كده عملنالها initialize في الكونستركتور

        dataRepo.getUserInfo(uId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .toObservable()
                .subscribe(new Observer<DocumentSnapshot>() {
                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onNext(DocumentSnapshot documentSnapshot) {
                        Users user = documentSnapshot.toObject(Users.class);
                        onUser.setValue(user);
                    }

                    @Override
                    public void onError(Throwable e) {

                    }

                    @Override
                    public void onComplete() {

                    }
                });



    }


    public void updateUserInfo(String name, String status) {
        dataRepo.updateName_Status(name, status)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new CompletableObserver() {
                    @Override
                    public void onSubscribe(Disposable d) {
                        disposable.add(d);
                        onStatusChange.setValue(StateResource.loading());

                    }

                    @Override
                    public void onComplete() {
                        onStatusChange.setValue(StateResource.success());

                    }

                    @Override
                    public void onError(Throwable e) {
                        onStatusChange.setValue(StateResource.error(e.getMessage()));

                    }
                });


    }

    public void updateImage(Bitmap image) {
        dataRepo.updateProfileImage(image)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new CompletableObserver() {
                    @Override
                    public void onSubscribe(Disposable d) {
                    }

                    @Override
                    public void onComplete() {
                    }

                    @Override
                    public void onError(Throwable e) {
                    }
                });

    }

    public LiveData<Users> onUserInfo() {
        return onUser;
    }

    public LiveData<StateResource> observerInfoChange() {
        return onStatusChange;
    }

    public LiveData<StateResource> observeDisplayImageChange() {
        return onDisplayImageChange;
    }


    @Override
    protected void onCleared() {
        super.onCleared();
        disposable.clear();
    }
}




