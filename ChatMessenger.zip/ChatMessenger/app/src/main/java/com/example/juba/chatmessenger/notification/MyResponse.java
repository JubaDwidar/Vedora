package com.example.juba.chatmessenger.notification;

public class MyResponse {
    public int success=0;
}
