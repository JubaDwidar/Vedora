package com.example.juba.chatmessenger.di.di_main.users;

import dagger.Module;

@Module
public class MessageModule {
}
