package com.example.juba.chatmessenger.utils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class StateResource<T> {

    @NonNull
    public final RegisterStatus status;

    @Nullable
    public final String message;


    public StateResource(@NonNull RegisterStatus status, @Nullable String message) {
        this.status = status;
        this.message = message;
    }

    public static <T> StateResource success () {
        return new StateResource<>(RegisterStatus.SUCCESS, null);
    }

    public static <T> StateResource error(@NonNull String msg) {

        return new StateResource<>(RegisterStatus.ERROR, msg);
    }

    public static <T> StateResource loading() {
        return new StateResource<>(RegisterStatus.LOADING, null);
    }

    public enum RegisterStatus  {
        SUCCESS,
        ERROR,
        LOADING
    }
}

